# -*- coding: utf-8 -*-
#!/usr/bin/env python
import socket
import sys
import select
import errno
import time
from Tkinter import *
from tkMessageBox import showinfo

class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 0))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


#UDP_IP ="192.168.1.111" # ip del socket
UDP_PORT = 30000  # Puerto del socket
Dir_IP = get_ip()

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
sock.bind((Dir_IP, UDP_PORT))
sock.setblocking(0)

ventana = Tk()

ventana.title('Conversor A/D & Socket UDP')
ventana.config(bg="beige") # Le da color al fondo
ventana.geometry("400x200") # Cambia el tamaño de la ventana

ventana.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana

w = Canvas(ventana, width=370, height= 70)
w.place(x=10, y=83)
w.config(bg="beige")
w.create_rectangle(10, 10, 360, 60)

x = 0
y = 0

#************************ FUNCIÓN RECURSIVA **********************************
def update_label():
    try:
        data,addr = sock.recvfrom(1024)
        #data,addr = sock.recv(1500)
    except socket.error, e:
        err = e.args[0]
        if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
            time.sleep(0.01)
            #print 'No hay datos!!'
            ventana.after(2, update_label)
    else:
        label_dato.config(text = data)    # Muestra el dato recibido
        ventana.after(2, update_label)

def info():
        showinfo(title='Acerca de..', message='Script en Python 2.7 \n www.firtec.com.ar')

def makemenu(parent):
    menubar = Frame(parent)
    menubar.pack(side=TOP, fill=X)

    fbutton = Menubutton(menubar, text='Menu', underline=0)
    fbutton.pack(side=LEFT)
    file = Menu(fbutton)
    file.add_command(label='Acerca de...', command=info,     underline=0)
    file.add_command(label='Salir',    command=parent.quit, underline=0)
    fbutton.config(menu=file)

makemenu(ventana)

#********* Label´s que despliegan la iformación y rótulos del script *********

label_Nombre_IP = Label(ventana, text="IP:", bg="beige", fg="blue", font=("Helvetica", 14))
label_Nombre_IP.place(x=30, y=30)

label_IP = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 14))
label_IP.config(text = Dir_IP)
label_IP.place(x=58, y=30)

label_Nombre_Puerto = Label(ventana, text="Puerto del Servidor:", bg="beige", fg="black", font=("Helvetica", 10))
label_Nombre_Puerto.place(x=200, y=165)

label_Puerto = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 10))
label_Puerto.config(text = UDP_PORT)
label_Puerto.place(x=320, y=165)

label_dato = Label(ventana, text="", bg="beige", fg="red", font=("Helvetica", 28))
label_dato.place(x=210, y=95)

label_voltaje = Label(ventana, text="Voltios:", bg="beige", fg="black", font=("Helvetica", 28))
label_voltaje.place(x=80, y=95)

update_label()
ventana.mainloop( )
